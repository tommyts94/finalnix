#!/usr/env/bin/ bash

DIR="$HOME/.config"

rofi -show emoji -modi emoji -theme $DIR/rofi/Themes/emojis.rasi
